# contracts

FOOT Token : 

Address : 0x2c154926B8a6bDE338BD8B9CE281e6D32Ba64193

BSC contract code : https://bscscan.com/address/0x2c154926B8a6bDE338BD8B9CE281e6D32Ba64193#code

FOOT Masterchef : 

Address : 0xd5844A33A20AC07e465716d6E493d813a128DaF9

BSC contract code : https://bscscan.com/address/0xd5844A33A20AC07e465716d6E493d813a128DaF9#code

