const SaladToken = artifacts.require('SaladToken.sol');
const MasterChef = artifacts.require('MasterChef.sol');
const SousChef = artifacts.require('SousChef.sol');
const SauceBar = artifacts.require('SauceBar.sol');
const BnbStaking = artifacts.require('BnbStaking.sol');
const LotteryRewardPool = artifacts.require('LotteryRewardPool.sol');
const Timelock = artifacts.require('Timelock.sol');
const MockBEP20 = artifacts.require('MockBEP20.sol');
const WETH = artifacts.require("WBNB.sol");

const LOTTERY_REWARDPOOL_RECEIVER = '0x837547b82ddd98a3F1674b72Fc80b49aDf53C557';

module.exports = async function(deployer, _network, addresses) {
  const [admin, _] = addresses;

  let weth;
  if( _network == 'bsc' ){
    weth = await WETH.at('0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c')
  } else if( _network == 'testnet' ){
    weth = await WETH.at('0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd')
  }

  

  await deployer.deploy(SaladToken);
  const saladToken = await SaladToken.deployed();

  await deployer.deploy(SauceBar, saladToken.address);
  const sauceBar = await SauceBar.deployed();

  await deployer.deploy(
    MasterChef,
    saladToken.address,
    sauceBar.address,
    admin,
    web3.utils.toWei('40'),           // _saladPerBlock
    7250000                            // _startBlock
    // 703820                            // _startBlock (pancakeswap mainnet)(2020-09-22)
  )
  const masterChef = await MasterChef.deployed();
  await saladToken.transferOwnership(masterChef.address);
  
  await deployer.deploy(
    SousChef,
    sauceBar.address,
    web3.utils.toWei('2'),            // _rewardPerBlock
    7350000,                           // _startBlock
    7600000                           // _endBlock
    // 879050,                           // _startBlock (pancakeswap mainnet)(2020-09-28)
    // 1029050                           // _endBlock (pancakeswap mainnet)(2020-10-3)
  )
  const sousChef = await SousChef.deployed();

  await deployer.deploy(
    LotteryRewardPool,
    masterChef.address,
    saladToken.address,
    admin,
    LOTTERY_REWARDPOOL_RECEIVER
  )
  const lotteryRewardPool = await LotteryRewardPool.deployed();

  
};

