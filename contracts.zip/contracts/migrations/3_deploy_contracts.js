const BnbStaking = artifacts.require('BnbStaking.sol');

module.exports = async function(deployer, _network, addresses) {
  const [admin, _] = addresses;

  let saladAddress, bnbAddress, busdAddress;
  if( _network == 'bsc' ) {
    saladAddress = "0x9EffAf5A3684c510263075e2E91d2594CcA671b2";
    bnbAddress = "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c";
  } else if( _network == 'testnet' ){
    saladAddress = "0x70cdfb73f78c51bf8a77b36c911d1f8c305d48e6";
    bnbAddress = "0xae13d989dac2f0debff460ac112a837c89baa7cd";
  }

  await deployer.deploy(
    BnbStaking,
    bnbAddress,                 //WBNB contract address
    saladAddress,               // saladtoken contract address
    web3.utils.toWei('0.5'), 
    7250000,                    // start block
    8250000,                    // end block
    admin,                      // admin address
    bnbAddress                  // WBNB contract address
  )
  const bnbStaking = await BnbStaking.deployed();
};

