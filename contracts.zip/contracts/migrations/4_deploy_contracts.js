const SmartChef = artifacts.require('SmartChef.sol');

module.exports = async function(deployer, _network, addresses) {
  const [admin, _] = addresses;

  let saladAddress, bnbAddress;
  if( _network == 'bsc' ) {
    saladAddress = "0x9EffAf5A3684c510263075e2E91d2594CcA671b2";
    bnbAddress = "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c";
  } else if( _network == 'testnet' ){
    saladAddress = "0x70cdfb73f78c51bf8a77b36c911d1f8c305d48e6";
    bnbAddress = "0xae13d989dac2f0debff460ac112a837c89baa7cd";
  }

  await deployer.deploy(
    SmartChef,
    saladAddress,                     // _syrup,(CAKE token)
    bnbAddress,                       // _rewardToken, (BNB token)
    web3.utils.toWei('0.0041'),       // _rewardPerBlock,
    7250000,                          // _startBlock,
    8250000,                          // _bonusEndBlock
  )
  const smartChef = await SmartChef.deployed();
};

