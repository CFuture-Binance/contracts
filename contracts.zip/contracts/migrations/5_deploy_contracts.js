const MasterChef = artifacts.require('MasterChef.sol');

module.exports = async function(deployer, _network, addresses) {
  let masterChef, saladBnbAddress, busdBnbAddress, ethBnbAddress;
  if( _network == 'bsc' ) {
    masterChef = await MasterChef.at('0x73feaa1eE314F8c655E354234017bE2193C9E24E')
    saladBnbAddress = "0xA527a61703D82139F8a06Bc30097cC9CAA2df5A6";
    busdBnbAddress = "0x1b96b92314c44b159149f7e0303511fb2fc4774f";
    ethBnbAddress = "0x70D8929d04b60Af4fb9B58713eBcf18765aDE422";
  } else if( _network == 'testnet' ){
    masterChef = await MasterChef.at('0x34f3D65814313f4Ddcdc2c52f9ce0c83F6e96084')
    saladBnbAddress = "0xCa1f193043C4da5Fd262C3D365456553147BBACE";
    busdBnbAddress = "0x1F6bc7FC277Aa532E2Ec377867323BC9520704d0";
    ethBnbAddress = "0x9C93C282dD2Bd3EB6647e06809fFF76bf2e07dc7";
  }

  let saladBnbResult = await masterChef.add( 4000, saladBnbAddress, true );
  let busdBnbResult = await masterChef.add( 4000, busdBnbAddress, true );
  let ethBnbResult = await masterChef.add( 4000, ethBnbAddress, true );

  console.log('-- saladBnbResult : ', saladBnbResult);
  console.log('-- busdBnbResult : ', busdBnbResult);
  console.log('-- ethBnbResult : ', ethBnbResult);
};

