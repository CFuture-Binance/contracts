const Multicall = artifacts.require('Multicall.sol');

module.exports = async function(deployer, _network, addresses) {
  const [admin, _] = addresses;

  await deployer.deploy(Multicall);
  const multicall = await Multicall.deployed();
};

